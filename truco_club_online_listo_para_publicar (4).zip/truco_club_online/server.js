const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const WebSocket = require('ws');

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, 'public');
const server = http.createServer((req, res) => {
  let pathname = decodeURIComponent((req.url || '/').split('?')[0]);
  if (pathname === '/') pathname = '/index.html';
  const file = path.join(PUBLIC, pathname.replace(/^\/+/, ''));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('No encontrado'); }
    const ext = path.extname(file);
    const types = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8'};
    res.writeHead(200, {'Content-Type': types[ext] || 'application/octet-stream', 'Cache-Control':'no-store'});
    res.end(data);
  });
});
const wss = new WebSocket.Server({server});
const rooms = new Map();
const suits = ['espada','basto','oro','copa'];
const ranks = [1,2,3,4,5,6,7,10,11,12];

function shuffledDeck() {
  const deck = [];
  suits.forEach((s, si) => ranks.forEach(n => deck.push({n, s:si})));
  for (let i=deck.length-1;i>0;i--) { const j=Math.floor(Math.random()*(i+1)); [deck[i],deck[j]]=[deck[j],deck[i]]; }
  return deck;
}
function power(c) {
  if(c.n===1&&c.s===0)return 14;
  if(c.n===1&&c.s===1)return 13;
  if(c.n===7&&c.s===0)return 12;
  if(c.n===7&&c.s===2)return 11;
  if(c.n===3)return 10;
  if(c.n===2)return 9;
  if(c.n===1)return 8;
  if(c.n===12)return 7;
  if(c.n===11)return 6;
  if(c.n===10)return 5;
  if(c.n===7)return 4;
  if(c.n===6)return 3;
  if(c.n===5)return 2;
  return 1;
}
function cardName(c) { return `${c.n} de ${suits[c.s]}`; }
function newHand(room) {
  const d = shuffledDeck();
  room.hands = [d.slice(0,3),d.slice(3,6)];
  room.played = [[],[]];
  room.tricks = [];
  room.turn = room.starter;
  room.bet = 1;
  room.betLevel = 0;
  room.pending = null;
  room.handOver = false;
  room.envidoUsed = false;
  room.firstPlayed = false;
  room.lastMessage = '¡Cartas repartidas! Que empiece el truco.';
  room.round += 1;
  room.log = [`Mano ${room.round}: empieza ${room.players[room.turn]?.name || ('Jugador '+(room.turn+1))}.`];
}
function publicState(room, seat) {
  return {
    roomId: room.id, status: room.players.filter(Boolean).length === 2 ? 'ready' : 'waiting',
    seat, players: room.players.map((p,i)=>p?{name:p.name,connected:!!p.ws&&p.ws.readyState===WebSocket.OPEN}:null),
    scores: room.scores, hands: room.hands.map((h,i)=>i===seat?h.map(c=>({...c})):h.map(()=>null)),
    handCounts: room.hands.map(h=>h.length), played: room.played, tricks: room.tricks,
    turn: room.turn, bet: room.bet, betLevel: room.betLevel, pending: room.pending,
    handOver: room.handOver, matchOver: room.matchOver, round: room.round,
    lastMessage: room.lastMessage, log: room.log.slice(-12), starter: room.starter
  };
}
function broadcast(room) {
  room.players.forEach((p,i)=>{
    if (p?.ws && p.ws.readyState===WebSocket.OPEN) {
      p.ws.send(JSON.stringify({type:'state', state:publicState(room,i)}));
    }
  });
}
function say(room, message) {
  room.lastMessage = message;
  room.log.push(message);
  if(room.log.length>30)room.log.shift();
}
function award(room, seat, points, message) {
  room.scores[seat] += points;
  say(room, message);
  room.handOver = true;
  room.pending = null;
  if(room.scores[seat] >= 15) {
    room.matchOver = true;
    say(room, `${room.players[seat]?.name || 'Jugador '+(seat+1)} ganó la partida. ¡Campeón!`);
  }
}
function envidoValue(room, seat) {
  const cards = room.hands[seat].concat(room.played[seat]);
  let best = 0;
  for(let si=0;si<4;si++) {
    const arr=cards.filter(c=>c.s===si).map(c=>c.n>=10?0:c.n).sort((a,b)=>b-a);
    if(arr.length>=2) best=Math.max(best,20+arr[0]+arr[1]);
    else if(arr.length===1) best=Math.max(best,arr[0]);
  }
  return best;
}
function playCard(room, seat, index) {
  if(room.status!=='ready'||room.handOver||room.matchOver||room.pending||room.turn!==seat) return;
  if(!Number.isInteger(index)||index<0||index>=room.hands[seat].length) return;
  const c=room.hands[seat].splice(index,1)[0];
  room.played[seat].push(c);
  room.firstPlayed=true;
  say(room, `${room.players[seat].name} jugó una carta.`);
  if(room.played[0].length===room.played[1].length) {
    const k=room.played[0].length-1, a=room.played[0][k], b=room.played[1][k];
    const winner=power(a)>power(b)?0:power(b)>power(a)?1:-1;
    room.tricks.push(winner);
    if(winner===-1) room.turn=room.starter; else room.turn=winner;
    say(room, winner<0?'La baza quedó parda.':`${room.players[winner].name} ganó la baza.`);
    const aWins=room.tricks.filter(x=>x===0).length, bWins=room.tricks.filter(x=>x===1).length;
    if(aWins>=2||bWins>=2||room.played[0].length>=3) {
      let w=aWins>bWins?0:bWins>aWins?1:room.starter;
      award(room,w,room.bet,`${room.players[w].name} ganó la mano y suma ${room.bet} punto(s).`);
    }
  } else room.turn=1-seat;
}
function action(room, seat, msg) {
  if(!room.players[seat] || room.status!=='ready') return;
  if(msg.action==='play') return playCard(room,seat,msg.index);
  if(room.handOver||room.matchOver) return;
  if(msg.action==='call-truco') {
    if(room.pending||room.betLevel>=3) return;
    room.betLevel++;
    room.bet=[2,3,4][room.betLevel-1];
    room.pending={kind:'truco',from:seat,level:room.betLevel};
    say(room,`${room.players[seat].name} cantó ${['TRUCO','RETRUCO','VALE CUATRO'][room.betLevel-1]}.`);
  } else if(msg.action==='call-envido') {
    if(room.pending||room.envidoUsed||room.firstPlayed) return;
    room.envidoUsed=true;
    room.pending={kind:'envido',from:seat,level:1};
    say(room,`${room.players[seat].name} cantó ENVIDO.`);
  } else if(msg.action==='accept') {
    if(!room.pending||room.pending.from===seat) return;
    const ch=room.pending; room.pending=null;
    if(ch.kind==='envido') {
      const a=envidoValue(room,0),b=envidoValue(room,1),w=a>=b?0:1;
      room.scores[w]+=2;
      say(room,`Envido: ${room.players[0].name} ${a} · ${room.players[1].name} ${b}. ${room.players[w].name} suma 2 puntos.`);
      room.lastMessage=`Envido resuelto: gana ${room.players[w].name}.`;
    } else say(room,'Apuesta aceptada. ¡A jugar!');
  } else if(msg.action==='reject') {
    if(!room.pending||room.pending.from===seat) return;
    const ch=room.pending; room.pending=null;
    if(ch.kind==='envido') {
      room.scores[ch.from]+=1;
      say(room,`Envido no querido. ${room.players[ch.from].name} suma 1 punto.`);
    } else {
      const pts=ch.level===1?1:ch.level===2?2:3;
      award(room,ch.from,pts,`${room.players[ch.from].name} ganó por no querido y suma ${pts} punto(s).`);
    }
  } else if(msg.action==='fold') {
    if(room.pending)return;
    award(room,1-seat,room.bet,`${room.players[seat].name} se fue al mazo. Punto para ${room.players[1-seat].name}.`);
  } else if(msg.action==='new-hand') {
    if(!room.handOver||room.matchOver||room.players[room.starter]?.ws!==room.players[seat]?.ws)return;
    room.starter=1-room.starter;
    newHand(room);
  } else if(msg.action==='rematch') {
    if(room.players[0]?.ws!==room.players[seat]?.ws)return;
    room.scores=[0,0];room.matchOver=false;room.handOver=false;room.round=0;room.starter=0;newHand(room);
  }
}
wss.on('connection',(ws)=>{
  let room=null,seat=null;
  ws.on('message',(raw)=>{
    let msg; try{msg=JSON.parse(raw.toString())}catch{return}
    if(msg.type==='join') {
      let id=String(msg.roomId||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,8);
      if(!id) id=crypto.randomBytes(3).toString('hex').toUpperCase();
      let r=rooms.get(id);
      if(!r) {
        r={id,players:[null,null],scores:[0,0],hands:[[],[]],played:[[],[]],tricks:[],turn:0,starter:0,bet:1,betLevel:0,pending:null,handOver:false,matchOver:false,round:0,envidoUsed:false,firstPlayed:false,lastMessage:'Esperando al segundo jugador...',log:[]};
        rooms.set(id,r);
      }
      let existing=r.players.findIndex(p=>p&&p.token===msg.token);
      if(existing>=0) seat=existing;
      else seat=r.players.findIndex(p=>!p || !p.ws || p.ws.readyState!==WebSocket.OPEN);
      if(seat<0) {ws.send(JSON.stringify({type:'error',message:'Esta partida ya tiene dos jugadores conectados.'}));return}
      room=r;
      room.players[seat]={ws,token:msg.token||crypto.randomBytes(8).toString('hex'),name:String(msg.name||`Jugador ${seat+1}`).slice(0,18)};
      if(room.players.filter(Boolean).length===2 && room.round===0) {room.status='ready';newHand(room)}
      else if(room.players.filter(Boolean).length===2) room.status='ready';
      else room.status='waiting';
      say(room,`${room.players[seat].name} se conectó.`);
      broadcast(room);
      return;
    }
    if(!room||seat===null)return;
    if(msg.type==='action') {action(room,seat,msg);broadcast(room)}
    if(msg.type==='rename') {room.players[seat].name=String(msg.name||`Jugador ${seat+1}`).slice(0,18);broadcast(room)}
  });
  ws.on('close',()=>{
    if(room&&seat!==null&&room.players[seat]?.ws===ws) {
      room.players[seat].ws=null;
      say(room,`${room.players[seat].name} se desconectó.`);
      broadcast(room);
    }
  });
});
server.listen(PORT,()=>console.log(`Truco Club Online en http://localhost:${PORT}`));
