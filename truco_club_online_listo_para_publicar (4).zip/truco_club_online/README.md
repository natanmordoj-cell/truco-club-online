# Truco Club Online

Juego de truco argentino para dos personas desde computadoras o celulares distintos. Cada jugador recibe únicamente sus propias cartas; las cartas del rival no se envían al navegador del otro jugador hasta que se juegan.

## Probarlo en tu computadora

1. Instalá Node.js 18 o más nuevo desde https://nodejs.org/
2. Descomprimí el ZIP.
3. Abrí una terminal en la carpeta `truco_club_online`.
4. Ejecutá:

   ```bash
   npm install
   npm start
   ```

5. Abrí http://localhost:3000

`localhost` solo funciona en tu computadora. Para jugar con un amigo por internet, publicá esta carpeta en un servicio que admita aplicaciones Node.js y WebSockets (por ejemplo Render, Railway o un servidor propio). El servicio debe ejecutar `npm start` y asignar el puerto mediante la variable `PORT`.

## Publicar online

- Subí el contenido de esta carpeta a un repositorio Git.
- En un hosting Node.js, creá un servicio web a partir del repositorio.
- Build command: `npm install`
- Start command: `npm start`
- Usá el dominio HTTPS que te dé el hosting.
- Entrá a ese dominio, escribí tu nombre y tocá **Crear partida**. Aparecerán el link de invitación y un código de sala de 6 caracteres. Mandale cualquiera de los dos a tu amigo. Si usa el código, entra al mismo dominio, escribe su nombre y el código y toca **Unirme con código**. Si abre el link, verá el código ya completado.

No se puede generar un link público permanente desde el archivo ZIP por sí solo: el servidor debe estar publicado para que ambos jugadores se conecten.

## Cómo se juega

- Primero en llegar a 15 puntos gana.
- Truco, retruco y vale cuatro tienen respuestas de “Quiero” o “No quiero”.
- Envido compara tantos de las cartas del mismo palo.
- El servidor mantiene las cartas y el estado de la partida, y envía a cada jugador solo su propia mano.

## Importante: versión inicial

Es un prototipo funcional de multijugador, no una implementación completa de todas las reglas oficiales. Se simplifican algunas situaciones del envido, las manos empatadas y las reglas de campeonato. No hay cuentas permanentes, chat ni sistema antitrampas avanzado. Las salas viven en memoria y se pierden si reiniciás el servidor.
